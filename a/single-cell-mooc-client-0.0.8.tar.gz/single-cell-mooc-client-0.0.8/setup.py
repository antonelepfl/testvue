#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup, find_packages

VERSION = '0.0.8'

setup(
    name='single-cell-mooc-client',
    version=VERSION,
    author='NSE',
    author_email='',
    description='IPython widget to submit answers on notebook',
    packages=find_packages(),
)
