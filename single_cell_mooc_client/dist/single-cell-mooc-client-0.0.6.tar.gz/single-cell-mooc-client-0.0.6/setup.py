#!/usr/bin/env python
# -*- coding: utf-8 -*-

from setuptools import setup

VERSION = '0.0.6'

setup(
    name='single-cell-mooc-client',
    version=VERSION,
    author='NSE',
    author_email='',
    description='IPython widget to submit answers on notebook',
)
