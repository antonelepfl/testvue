""" voxcellview version """
VERSION = '2.1.3.dev2'
