

# !pip install pyunicore --upgrade
import pprint
from os import makedirs
from os.path import join, exists
import pyunicore.client as unicore_client

base = 'https://zam2125.zam.kfa-juelich.de:9112/NUVLA/rest/core'
FILES_LIST = None
CIRCUIT_DIR = None
LOCAL_DIR = None

def joke():
  return (u'Wnwn ist das Nunst\u00fcck git und Slotermeyer? Ja! ... '
          u'Beiherhund das Oder die Flipperwaldt gersput.')


def define_paths(working_dir='/home/jovyan/tmp/test_pull_unicore', circuit_dir='/mnt/circuits/O1/20181114'):
  global LOCAL_DIR
  global CIRCUIT_DIR
  LOCAL_DIR = working_dir
  if not exists(LOCAL_DIR):
    print('Creating working_dir')
    makedirs(LOCAL_DIR)
  CIRCUIT_DIR = circuit_dir


# function to download the file and add it to kernel file system
def download_file_to_storage(file_name):
  x = files_list[file_name]
  file_content = x.raw().read()

  new_path = join(LOCAL_DIR, file_name)

  if file_name == 'BlueConfig':
      writable_content = file_content.replace('/mooc', '/mnt')
      writable_content = writable_content.replace('/io', LOCAL_DIR)
  else:
      writable_content = file_content

  with open(new_path, 'w') as fd:
      fd.write(writable_content)

  print('{} created!'.format(new_path))


def retrieve_sim_info(token, sim_url=join(base, '/jobs/81eaa147-30cf-4510-b702-d54a385df8d7')):
  tr = unicore_client.Transport(token)
  job_url = sim_url
  job = unicore_client.Job(tr, job_url)
  print('Simulation Name: {}'.format(job.properties['name']))
  storage = job.working_dir
  print('Files:')
  global files_list
  files_list = storage.listdir()
  pprint.pprint(files_list)


def download_blueconfig(file_name='BlueConfig'):
  # pull the BlueConfig with Unicore
  download_file_to_storage(file_name)


def download_report():
  # find report
  report = next((x for x in files_list if '_report_' in x), None)
  # pull report
  download_file_to_storage(report)


def download_out_dat():
  # pull the out.dat
  download_file_to_storage('out.dat')


def get_sim_results():
  download_blueconfig()
  download_report()
  download_out_dat()


def fetch_results(token, sim_url):
  retrieve_sim_info(token, sim_url)
  get_sim_results()


# def main(token, sim_url):
#   tr = unicore_client.Transport(token)
#   retrieve_sim_info(tr, sim_url)


# if __name__ == '__main__':
#     # logging.basicConfig(level=logging.INFO)
#     main()
