from setuptools import setup

setup(name='uc_pkg',
      version='0.1.2',
      description='Machinary to check newer version of notebook',
      author='Stefano Antonel',
      author_email='stefano.antonel@epfl.ch',
      license='MIT',
      packages=['uc_pkg'],
      install_requires=[
        # 'pyunicore',
        # 'PyJWT',
      ],
      zip_safe=True)